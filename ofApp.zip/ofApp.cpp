#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

	ifstream file_("services.txt");//reads from txt file 
	if (file_.is_open()) {
		while (getline(file_, line_)) {//for some reason puts out that number every time there is a return
			std::cout << line_ << '/n';
		}
		file_.close();
	}
	else
		std::cout << "file is not open" << '/n';
}

//--------------------------------------------------------------
void ofApp::update(){
	
}

//--------------------------------------------------------------
void ofApp::draw(){
		system("systemctl status mosquitto");// i know this wont work but i didnt manage to finish in time
		system("systemctl status autosys");
		system("systemctl status armcontroller");
	//la parte che non sono riuscito a completare in tempo riguarda il monitoraggio dei processi, fondamentalmente perche non ho mai usato linux in vita mia, ne pipes, 
		//quindi mi ci � voluto un bel po di tempo e ricerche per riuscire a capire come operare linux anche per cose stupide
		//per quanto riguarda il monitoraggio in particolare non sono riuscito a trovare un modo per mandare l'output del terminal al codice in modo da poterlo usare in qualche
		//variabile da poter poi mostrare con una semplice gui, credo uno dei metodi utilizzabili sia popen, ma non son riuscito in tempo a farlo
	
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
	
	if (key == 'm') {//keyboards interactions to start and stop easily the services
		system("systemctl start mosquitto");
	}
	if (key == 'n') {
		system("systemctl stop mosquitto");
	}
	if (key == 'a') {
		system("systemctl start autosys");
	}
	if (key == 'b') {
		system("systemctl stop autosys");
	}
	if (key == 'r') {
		system("systemctl start armcontroller");
	}
	if (key == 's') {
		system("systemctl stop armcontroller");
	}

}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){

}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){

}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){

}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){

}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){

}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){

}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){

}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){ 

}
